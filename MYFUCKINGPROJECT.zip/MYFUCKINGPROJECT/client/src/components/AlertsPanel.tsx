import { useState } from "react";
import { Button } from "@/components/ui/button";
import type { CryptoAlert } from "@/types/crypto";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";

interface AlertsPanelProps {
  alerts: CryptoAlert[];
}

export function AlertsPanel({ alerts }: AlertsPanelProps) {
  const [expandedAlert, setExpandedAlert] = useState<string | null>(null);
  const { toast } = useToast();

  const unreadAlerts = alerts.filter(alert => !alert.isRead);
  const recentAlerts = alerts.slice(0, 5);

  const markAsRead = async (alertId: string) => {
    try {
      await apiRequest("PATCH", `/api/alerts/${alertId}/read`);
      queryClient.invalidateQueries({ queryKey: ['/api/alerts'] });
      toast({
        title: "Alert marked as read",
        description: "Alert has been marked as read successfully.",
      });
    } catch (error) {
      toast({
        title: "Failed to mark alert as read",
        description: "Please try again.",
        variant: "destructive",
      });
    }
  };

  const getSeverityColor = (severity: string): string => {
    switch (severity) {
      case 'critical':
        return 'bg-red-500/10 border-red-500/20';
      case 'high':
        return 'bg-destructive/10 border-destructive/20';
      case 'medium':
        return 'bg-yellow-500/10 border-yellow-500/20';
      case 'low':
        return 'bg-green-500/10 border-green-500/20';
      default:
        return 'bg-muted/10 border-border';
    }
  };

  const getSeverityDot = (severity: string): string => {
    switch (severity) {
      case 'critical':
        return 'bg-red-500';
      case 'high':
        return 'bg-destructive';
      case 'medium':
        return 'bg-yellow-500';
      case 'low':
        return 'bg-green-500';
      default:
        return 'bg-muted-foreground';
    }
  };

  const formatTimestamp = (timestamp: Date | null): string => {
    if (!timestamp) return 'Unknown';
    const now = new Date();
    const alertTime = new Date(timestamp);
    const diffMs = now.getTime() - alertTime.getTime();
    const diffMins = Math.floor(diffMs / 60000);

    if (diffMins < 1) return 'Just now';
    if (diffMins < 60) return `${diffMins} minutes ago`;
    if (diffMins < 1440) return `${Math.floor(diffMins / 60)} hours ago`;
    return alertTime.toLocaleDateString();
  };

  return (
    <div className="space-y-6">
      {/* Recent Alerts */}
      <div className="bg-card border border-cyan-400/30 rounded-lg hover:border-cyan-400/50 hover:shadow-lg hover:shadow-cyan-400/20 transition-all duration-300">
        <div className="p-4 border-b border-border">
          <div className="flex items-center justify-between">
            <h3 className="font-semibold">Recent Alerts</h3>
            <span 
              className="bg-destructive/20 text-destructive px-2 py-1 rounded text-xs font-medium"
              data-testid="text-unread-count"
            >
              {unreadAlerts.length} New
            </span>
          </div>
        </div>
        <div className="p-4 space-y-3">
          {recentAlerts.length === 0 ? (
            <div className="text-center py-8 text-muted-foreground">
              <p>No recent alerts</p>
              <p className="text-sm">System is monitoring for new activity</p>
            </div>
          ) : (
            recentAlerts.map((alert) => (
              <div 
                key={alert.id} 
                className={`p-3 border border-cyan-400/20 rounded-lg transition-all duration-300 hover:bg-gradient-to-br hover:from-cyan-400/10 hover:to-purple-600/10 hover:border-cyan-400/40 hover:shadow-md hover:shadow-cyan-400/20 ${getSeverityColor(alert.severity)}`}
                data-testid={`alert-${alert.id}`}
              >
                <div className="flex items-start space-x-3">
                  <div className={`w-2 h-2 rounded-full mt-2 ${getSeverityDot(alert.severity)}`}></div>
                  <div className="flex-1">
                    <div className="text-sm font-medium" data-testid={`alert-title-${alert.id}`}>
                      {alert.title}
                    </div>
                    <div 
                      className="text-xs text-muted-foreground cursor-pointer"
                      onClick={() => setExpandedAlert(expandedAlert === alert.id ? null : alert.id)}
                      data-testid={`alert-description-${alert.id}`}
                    >
                      {expandedAlert === alert.id 
                        ? alert.description 
                        : `${alert.description.slice(0, 80)}${alert.description.length > 80 ? '...' : ''}`
                      }
                    </div>
                    <div className="text-xs text-muted-foreground mt-1" data-testid={`alert-time-${alert.id}`}>
                      {formatTimestamp(alert.createdAt)}
                    </div>
                  </div>
                  <div className="flex space-x-2">
                    <Button 
                      variant="ghost" 
                      size="sm" 
                      className="text-xs text-primary hover:underline"
                      onClick={() => setExpandedAlert(expandedAlert === alert.id ? null : alert.id)}
                      data-testid={`button-view-${alert.id}`}
                    >
                      {expandedAlert === alert.id ? 'Hide' : 'View'}
                    </Button>
                    {!alert.isRead && (
                      <Button 
                        variant="ghost" 
                        size="sm" 
                        className="text-xs text-muted-foreground hover:text-foreground"
                        onClick={() => markAsRead(alert.id)}
                        data-testid={`button-mark-read-${alert.id}`}
                      >
                        Mark as read
                      </Button>
                    )}
                  </div>
                </div>
              </div>
            ))
          )}
        </div>
        <div className="p-4 border-t border-border">
          <Button 
            variant="ghost" 
            className="w-full text-sm text-primary hover:underline"
            data-testid="button-view-all-alerts"
          >
            View all alerts
          </Button>
        </div>
      </div>
    </div>
  );
}
