import type { DataSource } from "@/types/crypto";

interface DataSourcesStatusProps {
  dataSources: DataSource[];
}

export function DataSourcesStatus({ dataSources }: DataSourcesStatusProps) {
  const getStatusIndicator = (status: string): string => {
    switch (status) {
      case 'active':
        return 'status-indicator status-active';
      case 'warning':
        return 'status-indicator status-warning';
      case 'error':
        return 'status-indicator status-error';
      default:
        return 'status-indicator bg-muted-foreground';
    }
  };

  const formatLastUpdate = (lastUpdate: Date | null): string => {
    if (!lastUpdate) return 'Never';
    const now = new Date();
    const updateTime = new Date(lastUpdate);
    const diffMs = now.getTime() - updateTime.getTime();
    const diffSecs = Math.floor(diffMs / 1000);
    const diffMins = Math.floor(diffSecs / 60);

    if (diffSecs < 60) return `${diffSecs}s ago`;
    if (diffMins < 60) return `${diffMins}m ago`;
    return updateTime.toLocaleTimeString();
  };

  return (
    <div className="bg-card border border-border rounded-lg">
      <div className="p-4 border-b border-border">
        <h3 className="font-semibold">Data Sources</h3>
      </div>
      <div className="p-4 space-y-3">
        {dataSources.length === 0 ? (
          <div className="text-center py-4 text-muted-foreground">
            <p>No data sources configured</p>
          </div>
        ) : (
          dataSources.map((source) => (
            <div 
              key={source.id} 
              className="flex items-center justify-between"
              data-testid={`datasource-${source.name}`}
            >
              <div className="flex items-center space-x-2">
                <span className={getStatusIndicator(source.status)}></span>
                <span className="text-sm font-medium" data-testid={`datasource-name-${source.name}`}>
                  {source.name}
                </span>
                {source.status === 'error' && source.errorMessage && (
                  <span 
                    className="text-xs text-red-400 ml-2"
                    title={source.errorMessage}
                    data-testid={`datasource-error-${source.name}`}
                  >
                    (Error)
                  </span>
                )}
              </div>
              <div className="text-xs text-muted-foreground" data-testid={`datasource-update-${source.name}`}>
                {formatLastUpdate(source.lastUpdate)}
              </div>
            </div>
          ))
        )}
      </div>
    </div>
  );
}
