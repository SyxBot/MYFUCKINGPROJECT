import { TrendingUp, Coins, BarChart3, Heart } from "lucide-react";
import type { SystemMetrics } from "@/types/crypto";

interface MetricsCardsProps {
  metrics: SystemMetrics | null;
}

export function MetricsCards({ metrics }: MetricsCardsProps) {
  const formatNumber = (num: number): string => {
    if (num >= 1000000000) {
      return `${(num / 1000000000).toFixed(1)}B`;
    } else if (num >= 1000000) {
      return `${(num / 1000000).toFixed(1)}M`;
    } else if (num >= 1000) {
      return `${(num / 1000).toFixed(1)}K`;
    }
    return num.toString();
  };

  return (
    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
      <div className="metric-card bg-gradient-to-br from-cyan-400/5 to-purple-600/5 border-cyan-400/30 hover:border-cyan-400/60 hover:shadow-lg hover:shadow-cyan-400/20 transition-all duration-300">
        <div className="flex items-center justify-between mb-2">
          <h3 className="text-sm font-medium text-muted-foreground">Active Tokens</h3>
          <Coins className="w-4 h-4 text-primary" />
        </div>
        <div className="text-2xl font-bold" data-testid="metric-active-tokens">
          {metrics?.activeTokens || 0}
        </div>
        <div className="text-sm text-green-400 flex items-center mt-1">
          <TrendingUp className="w-3 h-3 mr-1" />
          <span>Monitoring</span>
        </div>
      </div>
      
      <div className="metric-card bg-gradient-to-br from-cyan-400/5 to-purple-600/5 border-cyan-400/30 hover:border-cyan-400/60 hover:shadow-lg hover:shadow-cyan-400/20 transition-all duration-300">
        <div className="flex items-center justify-between mb-2">
          <h3 className="text-sm font-medium text-muted-foreground">Total Volume (24h)</h3>
          <BarChart3 className="w-4 h-4 text-primary" />
        </div>
        <div className="text-2xl font-bold" data-testid="metric-total-volume">
          ${formatNumber(Number(metrics?.totalVolume24h || 0))}
        </div>
        <div className="text-sm text-green-400 flex items-center mt-1">
          <TrendingUp className="w-3 h-3 mr-1" />
          <span>Live tracking</span>
        </div>
      </div>
      
      <div className="metric-card bg-gradient-to-br from-cyan-400/5 to-purple-600/5 border-cyan-400/30 hover:border-cyan-400/60 hover:shadow-lg hover:shadow-cyan-400/20 transition-all duration-300">
        <div className="flex items-center justify-between mb-2">
          <h3 className="text-sm font-medium text-muted-foreground">Alerts Sent</h3>
          <div className="w-4 h-4 bg-primary rounded-full flex items-center justify-center">
            <span className="text-primary-foreground text-xs font-bold">!</span>
          </div>
        </div>
        <div className="text-2xl font-bold" data-testid="metric-alerts-sent">
          {metrics?.alertsSent || 0}
        </div>
        <div className="text-sm text-muted-foreground flex items-center mt-1">
          <span>Today</span>
        </div>
      </div>
      
      <div className="metric-card bg-gradient-to-br from-cyan-400/5 to-purple-600/5 border-cyan-400/30 hover:border-cyan-400/60 hover:shadow-lg hover:shadow-cyan-400/20 transition-all duration-300">
        <div className="flex items-center justify-between mb-2">
          <h3 className="text-sm font-medium text-muted-foreground">API Health</h3>
          <Heart className="w-4 h-4 text-primary" />
        </div>
        <div className="text-2xl font-bold text-green-400" data-testid="metric-api-health">
          {metrics?.apiHealthScore || 0}%
        </div>
        <div className="text-sm text-muted-foreground flex items-center mt-1">
          <span className="status-indicator status-active mr-2"></span>
          <span>All systems operational</span>
        </div>
      </div>
    </div>
  );
}
