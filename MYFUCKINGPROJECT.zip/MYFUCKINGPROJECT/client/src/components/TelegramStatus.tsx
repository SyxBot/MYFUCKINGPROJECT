import { Button } from "@/components/ui/button";
import { Send } from "lucide-react";
import type { TelegramStatus } from "@/types/crypto";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { useState } from "react";

interface TelegramStatusProps {
  status: TelegramStatus;
}

export function TelegramStatus({ status }: TelegramStatusProps) {
  const [isSending, setIsSending] = useState(false);
  const { toast } = useToast();

  const sendTestMessage = async () => {
    setIsSending(true);
    try {
      const response = await apiRequest("POST", "/api/telegram/test");
      const data = await response.json();
      
      if (data.success) {
        toast({
          title: "Test message sent",
          description: "Successfully sent test message to Telegram.",
        });
      } else {
        toast({
          title: "Failed to send test message",
          description: data.message || "Unknown error occurred.",
          variant: "destructive",
        });
      }
    } catch (error) {
      toast({
        title: "Failed to send test message",
        description: "Please check your Telegram configuration.",
        variant: "destructive",
      });
    } finally {
      setIsSending(false);
    }
  };

  const formatLastSummary = (lastSummary: Date | null): string => {
    if (!lastSummary) return 'Never';
    return new Date(lastSummary).toLocaleTimeString();
  };

  return (
    <div className="bg-card border border-border rounded-lg">
      <div className="p-4 border-b border-border">
        <h3 className="font-semibold">Telegram Bot</h3>
      </div>
      <div className="p-4 space-y-3">
        <div className="flex items-center justify-between">
          <span className="text-sm">Status</span>
          <div className="flex items-center space-x-2">
            <span className={`status-indicator ${status.isActive ? 'status-active' : 'status-error'}`}></span>
            <span 
              className={`text-sm ${status.isActive ? 'text-green-400' : 'text-red-400'}`}
              data-testid="telegram-status"
            >
              {status.isActive ? 'Connected' : 'Disconnected'}
            </span>
          </div>
        </div>
        
        <div className="flex items-center justify-between">
          <span className="text-sm">Messages Today</span>
          <span className="text-sm font-medium" data-testid="telegram-messages-count">
            {status.messagesSent}
          </span>
        </div>
        
        <div className="flex items-center justify-between">
          <span className="text-sm">Last Summary</span>
          <span className="text-sm text-muted-foreground" data-testid="telegram-last-summary">
            {formatLastSummary(status.lastSummary)}
          </span>
        </div>
        
        <Button 
          onClick={sendTestMessage}
          disabled={!status.isActive || isSending}
          className="w-full mt-3"
          data-testid="button-test-telegram"
        >
          <Send className={`w-4 h-4 mr-1 ${isSending ? 'animate-pulse' : ''}`} />
          {isSending ? 'Sending...' : 'Send Test Message'}
        </Button>
      </div>
    </div>
  );
}
