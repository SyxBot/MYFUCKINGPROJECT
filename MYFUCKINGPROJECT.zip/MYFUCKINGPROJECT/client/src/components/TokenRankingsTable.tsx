import { useState, useEffect } from "react";
import { Button } from "@/components/ui/button";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { RefreshCw, Plus, ChevronLeft, ChevronRight, TrendingUp, TrendingDown, Minus } from "lucide-react";
import type { CryptoToken } from "@/types/crypto";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";

interface TokenRankingsTableProps {
  tokens: CryptoToken[];
  onRefresh: () => void;
}

export function TokenRankingsTable({ tokens, onRefresh }: TokenRankingsTableProps) {
  const [filter, setFilter] = useState<string>("all");
  const [sortBy, setSortBy] = useState<string>("volume_24h_usd");
  const [sortOrder, setSortOrder] = useState<string>("desc");
  const [currentPage, setCurrentPage] = useState(1);
  const [isRefreshing, setIsRefreshing] = useState(false);
  const [sortedTokens, setSortedTokens] = useState<CryptoToken[]>([]);
  const { toast } = useToast();
  const itemsPerPage = 10;

  const fetchSortedTokens = async () => {
    try {
      const params = new URLSearchParams({
        sort: sortBy,
        order: sortOrder,
        limit: '50',
        offset: '0'
      });
      const response = await apiRequest("GET", `/api/tokens?${params}`);
      const data = await response.json();
      setSortedTokens(data as CryptoToken[]);
    } catch (error) {
      console.error('Failed to fetch sorted tokens:', error);
      setSortedTokens(tokens); // Fallback to props
    }
  };

  const filteredTokens = (sortedTokens.length > 0 ? sortedTokens : tokens).filter(token => {
    switch (filter) {
      case "top25":
        return (sortedTokens.length > 0 ? sortedTokens : tokens).indexOf(token) < 25;
      case "trending":
        return Number(token.priceChange24h || 0) > 5;
      default:
        return true;
    }
  });

  const totalPages = Math.ceil(filteredTokens.length / itemsPerPage);
  const startIndex = (currentPage - 1) * itemsPerPage;
  const displayedTokens = filteredTokens.slice(startIndex, startIndex + itemsPerPage);

  const handleRefresh = async () => {
    setIsRefreshing(true);
    try {
      await apiRequest("POST", "/api/system/refresh");
      await fetchSortedTokens();
      onRefresh();
      toast({
        title: "Data refreshed",
        description: "Token data has been updated successfully.",
      });
    } catch (error) {
      toast({
        title: "Refresh failed",
        description: "Failed to refresh token data. Please try again.",
        variant: "destructive",
      });
    } finally {
      setIsRefreshing(false);
    }
  };

  const handleSortChange = async (value: string) => {
    setSortBy(value);
    await fetchSortedTokens();
  };

  useEffect(() => {
    fetchSortedTokens();
  }, [sortBy, sortOrder]);

  const formatNumber = (num: string | null): string => {
    if (!num) return "N/A";
    const value = Number(num);
    if (value >= 1000000000) {
      return `$${(value / 1000000000).toFixed(1)}B`;
    } else if (value >= 1000000) {
      return `$${(value / 1000000).toFixed(1)}M`;
    } else if (value >= 1000) {
      return `$${(value / 1000).toFixed(1)}K`;
    }
    return `$${value.toFixed(2)}`;
  };

  const getTokenIcon = (symbol: string): string => {
    const colors = [
      'from-purple-400 to-pink-400',
      'from-blue-400 to-cyan-400',
      'from-orange-400 to-red-400',
      'from-green-400 to-teal-400',
      'from-yellow-400 to-orange-400',
      'from-indigo-400 to-purple-400',
    ];
    const index = symbol.charCodeAt(0) % colors.length;
    return colors[index];
  };

  const getPriceChangeIcon = (change: string | null) => {
    if (!change) return <Minus className="w-3 h-3" />;
    const value = Number(change);
    if (value > 0) return <TrendingUp className="w-3 h-3" />;
    if (value < 0) return <TrendingDown className="w-3 h-3" />;
    return <Minus className="w-3 h-3" />;
  };

  const getPriceChangeColor = (change: string | null): string => {
    if (!change) return "text-muted-foreground";
    const value = Number(change);
    if (value > 0) return "text-green-400";
    if (value < 0) return "text-red-400";
    return "text-muted-foreground";
  };

  const getScoreColor = (score: number | null): string => {
    if (!score) return "bg-muted text-muted-foreground";
    if (score >= 80) return "bg-green-500/20 text-green-400";
    if (score >= 60) return "bg-blue-500/20 text-blue-400";
    if (score >= 40) return "bg-yellow-500/20 text-yellow-400";
    return "bg-red-500/20 text-red-400";
  };

  return (
    <div className="lg:col-span-2">
      <div className="bg-card border border-cyan-400/30 rounded-lg hover:border-cyan-400/50 hover:shadow-lg hover:shadow-cyan-400/20 transition-all duration-300">
        <div className="p-4 border-b border-border flex items-center justify-between">
          <div className="flex items-center space-x-2">
            <h2 className="text-lg font-semibold">Top Tokens by Volume</h2>
            <span className="bg-primary/20 text-primary px-2 py-1 rounded text-xs font-medium">
              60s refresh
            </span>
          </div>
          <div className="flex items-center space-x-2">
            <Button 
              onClick={handleRefresh}
              disabled={isRefreshing}
              size="sm"
              data-testid="button-refresh"
            >
              <RefreshCw className={`w-4 h-4 mr-1 ${isRefreshing ? 'animate-spin' : ''}`} />
              Refresh
            </Button>
            <Select value={sortBy} onValueChange={handleSortChange}>
              <SelectTrigger className="w-40" data-testid="select-sort">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="volume_24h_usd">Volume (24h)</SelectItem>
                <SelectItem value="volume_1h_usd">Volume (1h)</SelectItem>
                <SelectItem value="price_change_24h">Price Δ (24h)</SelectItem>
                <SelectItem value="price_change_1h">Price Δ (1h)</SelectItem>
                <SelectItem value="liquidity_usd">Liquidity</SelectItem>
                <SelectItem value="whale_intent_score">Whale Score</SelectItem>
                <SelectItem value="holders">Trending</SelectItem>
              </SelectContent>
            </Select>
            <Select value={filter} onValueChange={setFilter}>
              <SelectTrigger className="w-32" data-testid="select-filter">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Tokens</SelectItem>
                <SelectItem value="top25">Top 25</SelectItem>
                <SelectItem value="trending">Trending</SelectItem>
              </SelectContent>
            </Select>
          </div>
        </div>
        
        <div className="overflow-x-auto">
          <table className="w-full">
            <thead className="bg-secondary/50">
              <tr className="text-left">
                <th className="p-3 text-sm font-medium text-muted-foreground">#</th>
                <th className="p-3 text-sm font-medium text-muted-foreground">Token</th>
                <th className="p-3 text-sm font-medium text-muted-foreground">Price</th>
                <th className="p-3 text-sm font-medium text-muted-foreground">24h Volume</th>
                <th className="p-3 text-sm font-medium text-muted-foreground">24h %</th>
                <th className="p-3 text-sm font-medium text-muted-foreground">Score</th>
                <th className="p-3 text-sm font-medium text-muted-foreground">Action</th>
              </tr>
            </thead>
            <tbody>
              {displayedTokens.map((token, index) => (
                <tr 
                  key={token.id} 
                  className="data-row border-b border-cyan-400/20 cursor-pointer hover:bg-gradient-to-br hover:from-cyan-400/10 hover:to-purple-600/10 hover:border-cyan-400/30 hover:shadow-sm hover:shadow-cyan-400/20 transition-all duration-300"
                  data-testid={`row-token-${token.symbol}`}
                >
                  <td className="p-3 text-sm font-medium">
                    {startIndex + index + 1}
                  </td>
                  <td className="p-3">
                    <div className="flex items-center space-x-3">
                      <div className={`w-8 h-8 rounded-full bg-gradient-to-br ${getTokenIcon(token.symbol)} flex items-center justify-center text-white font-semibold text-xs`}>
                        {token.symbol.slice(0, 3)}
                      </div>
                      <div>
                        <div className="font-medium" data-testid={`text-symbol-${token.symbol}`}>
                          {token.symbol}
                        </div>
                        <div className="text-xs text-muted-foreground" data-testid={`text-name-${token.symbol}`}>
                          {token.name}
                        </div>
                      </div>
                    </div>
                  </td>
                  <td className="p-3 font-medium" data-testid={`text-price-${token.symbol}`}>
                    {token.price ? `$${Number(token.price).toFixed(4)}` : "N/A"}
                  </td>
                  <td className="p-3 text-sm" data-testid={`text-volume-${token.symbol}`}>
                    {formatNumber(token.volume24h)}
                  </td>
                  <td className="p-3">
                    <span className={`flex items-center ${getPriceChangeColor(token.priceChange24h)}`} data-testid={`text-change-${token.symbol}`}>
                      {getPriceChangeIcon(token.priceChange24h)}
                      <span className="ml-1">
                        {token.priceChange24h ? `${Number(token.priceChange24h).toFixed(2)}%` : "N/A"}
                      </span>
                    </span>
                  </td>
                  <td className="p-3">
                    <span 
                      className={`px-2 py-1 rounded text-xs font-medium ${getScoreColor(token.alphaScore)}`}
                      data-testid={`text-score-${token.symbol}`}
                    >
                      {token.alphaScore || "N/A"}
                    </span>
                  </td>
                  <td className="p-3">
                    <Button 
                      variant="ghost" 
                      size="sm" 
                      className="text-primary hover:text-primary/80"
                      data-testid={`button-add-${token.symbol}`}
                    >
                      <Plus className="w-4 h-4" />
                    </Button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
        
        <div className="p-4 border-t border-border flex items-center justify-between">
          <span className="text-sm text-muted-foreground" data-testid="text-pagination-info">
            Showing {startIndex + 1}-{Math.min(startIndex + itemsPerPage, filteredTokens.length)} of {filteredTokens.length} tokens
          </span>
          <div className="flex items-center space-x-2">
            <Button 
              variant="outline" 
              size="sm" 
              onClick={() => setCurrentPage(prev => Math.max(1, prev - 1))}
              disabled={currentPage === 1}
              data-testid="button-previous-page"
            >
              <ChevronLeft className="w-4 h-4" />
            </Button>
            <Button 
              variant="outline" 
              size="sm" 
              onClick={() => setCurrentPage(prev => Math.min(totalPages, prev + 1))}
              disabled={currentPage === totalPages}
              data-testid="button-next-page"
            >
              <ChevronRight className="w-4 h-4" />
            </Button>
          </div>
        </div>
      </div>
    </div>
  );
}
