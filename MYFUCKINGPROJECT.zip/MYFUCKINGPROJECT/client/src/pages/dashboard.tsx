import { Bot, Download, FileText, RefreshCw } from "lucide-react";
import { Button } from "@/components/ui/button";
import { MetricsCards } from "@/components/MetricsCards";
import { TokenRankingsTable } from "@/components/TokenRankingsTable";
import { AlertsPanel } from "@/components/AlertsPanel";
import { DataSourcesStatus } from "@/components/DataSourcesStatus";
import { TelegramStatus } from "@/components/TelegramStatus";
import { useWebSocket } from "@/hooks/useWebSocket";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { useState } from "react";

export default function Dashboard() {
  const { data, isConnected, error } = useWebSocket();
  const [isRefreshing, setIsRefreshing] = useState(false);
  const { toast } = useToast();

  const handleManualRefresh = async () => {
    setIsRefreshing(true);
    try {
      await apiRequest("POST", "/api/system/refresh");
      toast({
        title: "System refresh initiated",
        description: "All data sources are being refreshed.",
      });
    } catch (error) {
      toast({
        title: "Refresh failed",
        description: "Failed to initiate system refresh.",
        variant: "destructive",
      });
    } finally {
      setIsRefreshing(false);
    }
  };

  const handleExportData = async () => {
    try {
      const response = await fetch("/api/export/tokens");
      const blob = await response.blob();
      const url = window.URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = 'tokens.csv';
      document.body.appendChild(a);
      a.click();
      window.URL.revokeObjectURL(url);
      document.body.removeChild(a);

      toast({
        title: "Export successful",
        description: "Token data has been exported to CSV.",
      });
    } catch (error) {
      toast({
        title: "Export failed",
        description: "Failed to export token data.",
        variant: "destructive",
      });
    }
  };

  if (error) {
    return (
      <div className="min-h-screen bg-background text-foreground font-sans flex items-center justify-center">
        <div className="text-center">
          <h1 className="text-2xl font-bold mb-4">Connection Error</h1>
          <p className="text-muted-foreground mb-4">{error}</p>
          <Button onClick={() => window.location.reload()}>
            <RefreshCw className="w-4 h-4 mr-2" />
            Retry
          </Button>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background text-foreground font-sans">
      {/* Header Navigation */}
      <header className="bg-card border-b border-border sticky top-0 z-50">
        <div className="container mx-auto px-4 py-3">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-4">
              <div className="flex items-center space-x-2">
                <Bot className="text-primary text-xl" />
                <h1 className="text-xl font-bold">ZukCrypto</h1>
              </div>
              <div className="flex items-center space-x-2 text-sm text-muted-foreground">
                <span className={`status-indicator ${isConnected ? 'status-active' : 'status-error'}`}></span>
                <span data-testid="system-status">
                  {isConnected ? 'Active Monitoring' : 'Disconnected'}
                </span>
              </div>
            </div>
            <div className="flex items-center space-x-4">
              <div className="flex items-center space-x-2 text-sm">
                <span className="text-blue-400">🔵</span>
                <span className="text-muted-foreground">Bot:</span>
                <span className={`status-indicator ${data?.telegram.isActive ? 'status-active' : 'status-error'}`}></span>
                <span className={`${data?.telegram.isActive ? 'text-green-400' : 'text-red-400'}`}>
                  {data?.telegram.isActive ? 'Connected' : 'Disconnected'}
                </span>
              </div>
            </div>
          </div>
        </div>
      </header>

      <main className="container mx-auto px-4 py-6 space-y-6">
        {/* Market Overview Cards */}
        <MetricsCards metrics={data?.metrics || null} />

        {/* Main Dashboard Grid */}
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          {/* Token Rankings Table */}
          <TokenRankingsTable 
            tokens={data?.tokens || []} 
            onRefresh={() => {}} 
          />

          {/* Alerts & Activity Panel */}
          <div className="space-y-6">
            <AlertsPanel alerts={data?.alerts || []} />
            <DataSourcesStatus dataSources={data?.dataSources || []} />
            <TelegramStatus 
              status={data?.telegram || { isActive: false, messagesSent: 0, lastSummary: null }} 
            />
          </div>
        </div>

        {/* Quick Actions Bar */}
        <div className="bg-card border border-cyan-400/30 rounded-lg p-4 hover:border-cyan-400/50 hover:shadow-lg hover:shadow-cyan-400/20 transition-all duration-300">
          <div className="flex items-center justify-between">
            <h3 className="font-semibold">Quick Actions</h3>
            <div className="flex items-center space-x-3">
              <Button 
                onClick={handleManualRefresh}
                disabled={isRefreshing}
                data-testid="button-manual-refresh"
              >
                <RefreshCw className={`w-4 h-4 mr-1 ${isRefreshing ? 'animate-spin' : ''}`} />
                Refresh All Data
              </Button>
              <Button 
                variant="secondary" 
                onClick={handleExportData}
                data-testid="button-export-data"
              >
                <Download className="w-4 h-4 mr-1" />
                Export CSV
              </Button>
              <Button 
                variant="secondary"
                data-testid="button-view-logs"
              >
                <FileText className="w-4 h-4 mr-1" />
                View Logs
              </Button>
            </div>
          </div>
        </div>
      </main>
    </div>
  );
}
