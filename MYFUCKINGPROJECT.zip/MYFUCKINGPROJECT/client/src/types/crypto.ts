export interface CryptoToken {
  id: string;
  symbol: string;
  name: string;
  mint: string;
  decimals: number;
  price: string | null;
  volume24h: string | null;
  priceChange24h: string | null;
  marketCap: string | null;
  holders: number | null;
  alphaScore: number | null;
  lastUpdated: Date | null;
  isActive: boolean | null;
}

export interface CryptoAlert {
  id: string;
  type: string;
  severity: string;
  title: string;
  description: string;
  tokenId: string | null;
  metadata: any;
  isRead: boolean | null;
  createdAt: Date | null;
}

export interface DataSource {
  id: string;
  name: string;
  status: string;
  lastUpdate: Date | null;
  errorMessage: string | null;
  requestCount: number | null;
}

export interface SystemMetrics {
  id: string;
  activeTokens: number | null;
  totalVolume24h: string | null;
  alertsSent: number | null;
  apiHealthScore: number | null;
  lastUpdated: Date | null;
}

export interface TelegramStatus {
  isActive: boolean;
  messagesSent: number;
  lastSummary: Date | null;
}

export interface SystemUpdate {
  type: 'system_update';
  data: {
    tokens: CryptoToken[];
    alerts: CryptoAlert[];
    metrics: SystemMetrics | null;
    dataSources: DataSource[];
    telegram: TelegramStatus;
    timestamp: string;
  };
}
