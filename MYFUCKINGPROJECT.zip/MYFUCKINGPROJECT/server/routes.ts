import type { Express } from "express";
import { createServer, type Server } from "http";
import { WebSocketServer, WebSocket } from "ws";
import { storage } from "./storage";
import { dataAggregator } from "./services/dataAggregator";
import { telegramService } from "./services/telegramService";
import { alertService } from "./services/alertService";

export async function registerRoutes(app: Express): Promise<Server> {
  const httpServer = createServer(app);

  // WebSocket server for real-time updates
  const wss = new WebSocketServer({ server: httpServer, path: '/ws' });

  wss.on('connection', (ws) => {
    console.log('Client connected to WebSocket');

    // Send initial data
    sendSystemUpdate(ws);

    // Set up periodic updates
    const interval = setInterval(async () => {
      if (ws.readyState === WebSocket.OPEN) {
        await sendSystemUpdate(ws);
      }
    }, 30000); // Every 30 seconds

    ws.on('close', () => {
      console.log('Client disconnected from WebSocket');
      clearInterval(interval);
    });

    ws.on('error', (error) => {
      console.error('WebSocket error:', error);
      clearInterval(interval);
    });
  });

  async function sendSystemUpdate(ws: WebSocket) {
    try {
      const tokens = await storage.getTopTokensByVolume(50);
      const alerts = await storage.getRecentAlerts(10);
      const metrics = await storage.getLatestSystemMetrics();
      const dataSources = await storage.getAllDataSources();
      const telegramConfig = await storage.getTelegramConfig();

      const data = {
        type: 'system_update',
        data: {
          tokens,
          alerts,
          metrics,
          dataSources,
          telegram: {
            isActive: telegramConfig?.isActive || false,
            messagesSent: telegramConfig?.messagesSent || 0,
            lastSummary: telegramConfig?.lastSummary || null,
          },
          timestamp: new Date().toISOString(),
        },
      };

      if (ws.readyState === WebSocket.OPEN) {
        ws.send(JSON.stringify(data));
      }
    } catch (error) {
      console.error('Error sending system update:', error);
    }
  }

  // API Routes

  // Get all tokens
  app.get("/api/tokens", async (req, res) => {
    try {
      const ALLOWED_SORTS = ['volume_24h_usd','volume_1h_usd','price_change_1h','price_change_24h','liquidity_usd','whale_intent_score','holders'];
      
      const sort = req.query.sort as string || 'volume_24h_usd';
      const order = req.query.order as string || 'desc';
      const limit = parseInt(req.query.limit as string) || 50;
      const offset = parseInt(req.query.offset as string) || 0;
      
      if (!ALLOWED_SORTS.includes(sort)) {
        return res.status(400).json({ error: `Invalid sort field. Allowed: ${ALLOWED_SORTS.join(', ')}` });
      }
      
      if (!['asc', 'desc'].includes(order)) {
        return res.status(400).json({ error: "Invalid order. Must be 'asc' or 'desc'" });
      }
      
      const tokens = await storage.getTokensSorted(sort, order, limit, offset);
      res.json(tokens);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch tokens" });
    }
  });

  // Get token by ID
  app.get("/api/tokens/:id", async (req, res) => {
    try {
      const token = await storage.getTokenById(req.params.id);
      if (!token) {
        return res.status(404).json({ error: "Token not found" });
      }
      res.json(token);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch token" });
    }
  });

  // Get all alerts
  app.get("/api/alerts", async (req, res) => {
    try {
      const unread = req.query.unread === 'true';
      const limit = parseInt(req.query.limit as string) || 20;
      
      const alerts = unread 
        ? await storage.getUnreadAlerts()
        : await storage.getRecentAlerts(limit);
      
      res.json(alerts);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch alerts" });
    }
  });

  // Mark alert as read
  app.patch("/api/alerts/:id/read", async (req, res) => {
    try {
      await storage.markAlertAsRead(req.params.id);
      res.json({ success: true });
    } catch (error) {
      res.status(500).json({ error: "Failed to mark alert as read" });
    }
  });

  // Get alert statistics
  app.get("/api/alerts/stats", async (req, res) => {
    try {
      const stats = await alertService.getAlertStatistics();
      res.json(stats);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch alert statistics" });
    }
  });

  // Get system metrics
  app.get("/api/metrics", async (req, res) => {
    try {
      const metrics = await storage.getLatestSystemMetrics();
      res.json(metrics);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch system metrics" });
    }
  });

  // Get data sources status
  app.get("/api/datasources", async (req, res) => {
    try {
      const dataSources = await storage.getAllDataSources();
      res.json(dataSources);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch data sources" });
    }
  });

  // Get system status
  app.get("/api/system/status", async (req, res) => {
    try {
      const status = await dataAggregator.getSystemStatus();
      const telegramStatus = telegramService.getStatus();
      
      res.json({
        ...status,
        telegram: telegramStatus,
      });
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch system status" });
    }
  });

  // Manual refresh data
  app.post("/api/system/refresh", async (req, res) => {
    try {
      // This would trigger a manual refresh
      dataAggregator.stopPolling();
      dataAggregator.startPolling();
      
      res.json({ success: true, message: "Data refresh initiated" });
    } catch (error) {
      res.status(500).json({ error: "Failed to refresh data" });
    }
  });

  // Send test Telegram message
  app.post("/api/telegram/test", async (req, res) => {
    try {
      const success = await telegramService.sendTestMessage();
      res.json({ success, message: success ? "Test message sent" : "Failed to send test message" });
    } catch (error) {
      res.status(500).json({ error: "Failed to send test message" });
    }
  });

  // Send manual summary
  app.post("/api/telegram/summary", async (req, res) => {
    try {
      const type = req.body.type || 'morning';
      let success = false;

      if (type === 'morning') {
        success = await telegramService.sendMorningSummary();
      } else if (type === 'evening') {
        success = await telegramService.sendEveningSummary();
      }

      res.json({ 
        success, 
        message: success ? `${type} summary sent` : `Failed to send ${type} summary` 
      });
    } catch (error) {
      res.status(500).json({ error: "Failed to send summary" });
    }
  });

  // Export data to CSV
  app.get("/api/export/tokens", async (req, res) => {
    try {
      const tokens = await storage.getAllTokens();
      
      const csvHeaders = 'Symbol,Name,Mint,Price,Volume 24h,Price Change 24h,Market Cap,Alpha Score,Last Updated\n';
      const csvData = tokens.map(token => 
        `${token.symbol},${token.name},${token.mint},${token.price || ''},${token.volume24h || ''},${token.priceChange24h || ''},${token.marketCap || ''},${token.alphaScore || ''},${token.lastUpdated}`
      ).join('\n');

      res.setHeader('Content-Type', 'text/csv');
      res.setHeader('Content-Disposition', 'attachment; filename=tokens.csv');
      res.send(csvHeaders + csvData);
    } catch (error) {
      res.status(500).json({ error: "Failed to export data" });
    }
  });

  return httpServer;
}
