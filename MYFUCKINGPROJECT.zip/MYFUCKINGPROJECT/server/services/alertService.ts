import { storage } from '../storage';
import { telegramService } from './telegramService';
import { shouldAlert } from '../../src/filters/whale';
import type { Token, Alert } from '@shared/schema';

export class AlertService {
  async createVolumeAlert(token: Token, previousVolume: number, currentVolume: number): Promise<Alert> {
    const increasePercent = ((currentVolume - previousVolume) / previousVolume) * 100;
    
    const alert = await storage.createAlert({
      type: 'volume',
      severity: increasePercent > 500 ? 'critical' : increasePercent > 200 ? 'high' : 'medium',
      title: 'High Volume Alert',
      description: `${token.symbol} volume increased by ${increasePercent.toFixed(1)}% in the last hour (${this.formatNumber(previousVolume)} → ${this.formatNumber(currentVolume)})`,
      tokenId: token.id,
      metadata: {
        previousVolume,
        currentVolume,
        increasePercent,
        tokenSymbol: token.symbol,
      },
    });

    // Send to Telegram if high or critical severity
    if (alert.severity === 'high' || alert.severity === 'critical') {
      await telegramService.sendAlert(alert);
    }

    return alert;
  }

  async createPriceAlert(token: Token, priceChangePercent: number): Promise<Alert> {
    const isPositive = priceChangePercent > 0;
    const severity = Math.abs(priceChangePercent) > 50 ? 'critical' : 
                    Math.abs(priceChangePercent) > 30 ? 'high' : 'medium';

    const alert = await storage.createAlert({
      type: 'price',
      severity,
      title: `Price ${isPositive ? 'Surge' : 'Drop'} Alert`,
      description: `${token.symbol} price ${isPositive ? 'increased' : 'decreased'} by ${Math.abs(priceChangePercent).toFixed(1)}% to $${token.price}`,
      tokenId: token.id,
      metadata: {
        priceChangePercent,
        currentPrice: token.price,
        tokenSymbol: token.symbol,
      },
    });

    // Send to Telegram if significant movement
    if (Math.abs(priceChangePercent) > 25) {
      await telegramService.sendAlert(alert);
    }

    return alert;
  }

  async createWhaleAlert(token: Token, volume: number, wallet: string = 'unknown'): Promise<Alert> {
    const meta = {};
    const res = shouldAlert(
      {
        wallet,
        mint: token.mint,
        symbol: token.symbol,
        isBuy: true,
        usd: volume,
        dex: 'aggregated',
        route: []
      },
      {
        liqUsd: token.marketCap ? Number(token.marketCap) * 0.1 : null,
        vol1hUsd: token.volume24h ? Number(token.volume24h) / 24 : null,
        holders: token.holders,
        tokenAgeH: null
      }
    );
    if (!res.alert) return null as any;

    // Calculate enrichment fields
    const lpUsd = token.marketCap ? Number(token.marketCap) * 0.1 : 0;
    const vol1hUsd = token.volume24h ? Number(token.volume24h) / 24 : 0;
    const lpPct = lpUsd > 0 ? ((volume / lpUsd) * 100).toFixed(1) : '0';
    const vol1hPct = vol1hUsd > 0 ? ((volume / vol1hUsd) * 100).toFixed(1) : '0';
    const walletQuality = Math.floor((0.3 + Math.random() * 0.4) * 100); // Mock: 30-70%
    const holderDelta = Math.floor(Math.random() * 20) - 10; // Mock: -10 to +10
    const lpAction = Math.random() > 0.5 ? 'add' : 'remove';

    const alert = await storage.createAlert({
      type: 'whale',
      severity: res.kind === 'WHALE_BURST' ? 'high' : 'medium',
      title: res.kind === 'WHALE_BURST' ? 'Whale Burst Activity' : 'Whale Activity Detected',
      description: `Large accumulation detected in ${token.symbol} with $${this.formatNumber(volume)} volume\n` +
                  `📊 ${lpPct}%LP • ${vol1hPct}%1h vol • Quality: ${walletQuality}%\n` +
                  `👥 Holders: ${holderDelta > 0 ? '+' : ''}${holderDelta}/1h • LP: ${lpAction}\n` +
                  `🎯 Alpha Score: ${token.alphaScore || 0} • Whale Score: ${token.whaleIntentScore || 0}`,
      tokenId: token.id,
      metadata: {
        volume,
        tokenSymbol: token.symbol,
        currentPrice: token.price,
        whaleContext: res.context,
        lpPct: Number(lpPct),
        vol1hPct: Number(vol1hPct),
        walletQuality,
        holderDelta,
        lpAction,
        alphaScore: token.alphaScore || 0,
      },
    });

    await telegramService.sendAlert(alert);
    return alert;
  }

  async createTrendAlert(token: Token, trendType: 'support' | 'resistance', level: number): Promise<Alert> {
    const alert = await storage.createAlert({
      type: 'trend',
      severity: 'low',
      title: 'Trend Detection',
      description: `${token.symbol} showing strong ${trendType} at $${level} level`,
      tokenId: token.id,
      metadata: {
        trendType,
        level,
        tokenSymbol: token.symbol,
        currentPrice: token.price,
      },
    });

    return alert;
  }

  async checkNewTokenAlert(tokenData: any): Promise<void> {
    // Check if it's a potentially high-value new token
    const volume = Number(tokenData.volume24h || 0);
    const alphaScore = tokenData.alphaScore || 0;

    if (volume > 1000000 && alphaScore > 80) {
      await storage.createAlert({
        type: 'trend',
        severity: 'medium',
        title: 'New High-Value Token Detected',
        description: `${tokenData.symbol} (${tokenData.name}) detected with $${this.formatNumber(volume)} volume and ${alphaScore} alpha score`,
        tokenId: null,
        metadata: {
          volume,
          alphaScore,
          tokenSymbol: tokenData.symbol,
          tokenName: tokenData.name,
        },
      });
    }
  }

  async getAlertStatistics(): Promise<{
    total: number;
    unread: number;
    byType: Record<string, number>;
    bySeverity: Record<string, number>;
  }> {
    const allAlerts = await storage.getAllAlerts();
    const unreadAlerts = await storage.getUnreadAlerts();

    const byType = allAlerts.reduce((acc, alert) => {
      acc[alert.type] = (acc[alert.type] || 0) + 1;
      return acc;
    }, {} as Record<string, number>);

    const bySeverity = allAlerts.reduce((acc, alert) => {
      acc[alert.severity] = (acc[alert.severity] || 0) + 1;
      return acc;
    }, {} as Record<string, number>);

    return {
      total: allAlerts.length,
      unread: unreadAlerts.length,
      byType,
      bySeverity,
    };
  }

  private formatNumber(num: number): string {
    if (num >= 1000000000) {
      return `${(num / 1000000000).toFixed(1)}B`;
    } else if (num >= 1000000) {
      return `${(num / 1000000).toFixed(1)}M`;
    } else if (num >= 1000) {
      return `${(num / 1000).toFixed(1)}K`;
    }
    return num.toFixed(2);
  }
}

export const alertService = new AlertService();
