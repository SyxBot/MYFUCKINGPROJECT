import { cryptoDataService } from './cryptoDataService';
import { alertService } from './alertService';
import { storage } from '../storage';
import { computeWhaleIntentScore } from '../../src/analytics/alpha';
import type { Token, SystemMetrics } from '@shared/schema';

export class DataAggregator {
  private isRunning: boolean = false;
  private top25Interval: NodeJS.Timeout | null = null;
  private top26to50Interval: NodeJS.Timeout | null = null;
  private metricsInterval: NodeJS.Timeout | null = null;

  constructor() {
    this.startPolling();
  }

  startPolling() {
    if (this.isRunning) return;
    
    this.isRunning = true;
    console.log('Starting data aggregation polling...');

    // Poll top 25 tokens every 60 seconds
    this.top25Interval = setInterval(async () => {
      await this.updateTopTokens(25);
    }, 60000);

    // Poll tokens 26-50 every 120 seconds
    this.top26to50Interval = setInterval(async () => {
      await this.updateRemainingTokens();
    }, 120000);

    // Update system metrics every 30 seconds
    this.metricsInterval = setInterval(async () => {
      await this.updateSystemMetrics();
    }, 30000);

    // Initial fetch
    this.updateTopTokens(50);
    this.updateSystemMetrics();
  }

  stopPolling() {
    this.isRunning = false;
    
    if (this.top25Interval) {
      clearInterval(this.top25Interval);
      this.top25Interval = null;
    }
    
    if (this.top26to50Interval) {
      clearInterval(this.top26to50Interval);
      this.top26to50Interval = null;
    }
    
    if (this.metricsInterval) {
      clearInterval(this.metricsInterval);
      this.metricsInterval = null;
    }
    
    console.log('Data aggregation polling stopped');
  }

  private async updateTopTokens(limit: number) {
    try {
      console.log(`Fetching top ${limit} tokens...`);
      const fetchedTokens = await cryptoDataService.fetchSolanaTokens();
      const topTokens = fetchedTokens.slice(0, limit);

      for (const tokenData of topTokens) {
        await this.processToken(tokenData);
      }

      console.log(`Successfully processed ${topTokens.length} tokens`);
    } catch (error) {
      console.error('Error updating top tokens:', error);
    }
  }

  private async updateRemainingTokens() {
    try {
      console.log('Fetching tokens 26-50...');
      const fetchedTokens = await cryptoDataService.fetchSolanaTokens();
      const remainingTokens = fetchedTokens.slice(25, 50);

      for (const tokenData of remainingTokens) {
        await this.processToken(tokenData);
      }

      console.log(`Successfully processed ${remainingTokens.length} additional tokens`);
    } catch (error) {
      console.error('Error updating remaining tokens:', error);
    }
  }

  private async processToken(tokenData: any) {
    try {
      // Compute whale intent score
      const whaleScore = computeWhaleIntentScore(
        {
          uniqueWallets: Math.floor(Math.random() * 20) + 5, // Mock: 5-25 wallets
          netBuyUsd: Number(tokenData.volume24h || 0) * 0.6, // Mock: 60% net buying
          slippageAvg: 0.02 + Math.random() * 0.03, // Mock: 2-5% slippage
        },
        {
          lpUsd: Number(tokenData.marketCap || 0) * 0.1, // Mock: 10% of mcap as liquidity
          vol1hUsd: Number(tokenData.volume24h || 0) / 24, // Mock: 1h = 24h/24
        },
        {
          hitRateAvg: 0.3 + Math.random() * 0.4, // Mock: 30-70% hit rate
        }
      );
      
      // Check if token already exists
      const existingToken = await storage.getTokenByMint(tokenData.mint);
      
      if (existingToken) {
        // Update existing token
        const updatedToken = await storage.updateToken(existingToken.id, {
          price: tokenData.price,
          volume24h: tokenData.volume24h,
          priceChange24h: tokenData.priceChange24h,
          marketCap: tokenData.marketCap,
          holders: tokenData.holders,
          alphaScore: tokenData.alphaScore,
          whaleIntentScore: whaleScore,
        });

        if (updatedToken) {
          // Check for alerts
          await this.checkForAlerts(existingToken, updatedToken);
        }
      } else {
        // Create new token
        await storage.createToken({
          symbol: tokenData.symbol,
          name: tokenData.name,
          mint: tokenData.mint,
          decimals: tokenData.decimals,
          price: tokenData.price,
          volume24h: tokenData.volume24h,
          priceChange24h: tokenData.priceChange24h,
          marketCap: tokenData.marketCap,
          holders: tokenData.holders,
          alphaScore: tokenData.alphaScore,
          whaleIntentScore: whaleScore,
        });

        // Check for new token alerts
        await alertService.checkNewTokenAlert(tokenData);
      }
    } catch (error) {
      console.error(`Error processing token ${tokenData.symbol}:`, error);
    }
  }

  private async checkForAlerts(previousToken: Token, currentToken: Token) {
    const previousVolume = Number(previousToken.volume24h || 0);
    const currentVolume = Number(currentToken.volume24h || 0);
    const previousPrice = Number(previousToken.price || 0);
    const currentPrice = Number(currentToken.price || 0);

    // Volume spike alert (150% increase)
    if (currentVolume > previousVolume * 2.5) {
      await alertService.createVolumeAlert(currentToken, previousVolume, currentVolume);
    }

    // Price movement alert (20% change)
    const priceChangePercent = ((currentPrice - previousPrice) / previousPrice) * 100;
    if (Math.abs(priceChangePercent) > 20) {
      await alertService.createPriceAlert(currentToken, priceChangePercent);
    }

    // Whale activity alert (very high volume with moderate price change)
    if (currentVolume > 5000000 && Math.abs(priceChangePercent) < 5) {
      await alertService.createWhaleAlert(currentToken, currentVolume);
    }
  }

  private async updateSystemMetrics() {
    try {
      const tokens = await storage.getAllTokens();
      const alerts = await storage.getAllAlerts();
      const dataSources = await storage.getAllDataSources();

      const totalVolume = tokens.reduce((sum, token) => 
        sum + Number(token.volume24h || 0), 0
      );

      const todayAlerts = alerts.filter(alert => {
        const alertDate = new Date(alert.createdAt || 0);
        const today = new Date();
        return alertDate.toDateString() === today.toDateString();
      });

      const activeDataSources = dataSources.filter(ds => ds.status === 'active');
      const healthScore = Math.round((activeDataSources.length / dataSources.length) * 100);

      await storage.updateSystemMetrics({
        activeTokens: tokens.length,
        totalVolume24h: totalVolume.toString(),
        alertsSent: todayAlerts.length,
        apiHealthScore: healthScore,
      });

    } catch (error) {
      console.error('Error updating system metrics:', error);
    }
  }

  async getSystemStatus() {
    const metrics = await storage.getLatestSystemMetrics();
    const dataSources = await storage.getAllDataSources();
    const tokens = await storage.getAllTokens();

    return {
      isRunning: this.isRunning,
      metrics,
      dataSources,
      tokenCount: tokens.length,
      lastUpdate: new Date().toISOString(),
    };
  }
}

export const dataAggregator = new DataAggregator();
