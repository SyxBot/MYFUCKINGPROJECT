import axios from 'axios';
import { storage } from '../storage';
import type { Alert, Token, SystemMetrics } from '@shared/schema';

export class TelegramService {
  private botToken: string;
  private chatId: string;
  private isActive: boolean = false;

  constructor() {
    this.botToken = process.env.TELEGRAM_BOT_TOKEN || process.env.VITE_TELEGRAM_BOT_TOKEN || '';
    this.chatId = process.env.TELEGRAM_CHAT_ID || process.env.VITE_TELEGRAM_CHAT_ID || '';
    this.initializeConfig();
  }

  private async initializeConfig() {
    if (this.botToken && this.chatId) {
      this.isActive = true;
      await storage.updateTelegramConfig({
        botToken: this.botToken,
        chatId: this.chatId,
        isActive: true,
        messagesSent: 0,
      });
    }
  }

  async sendAlert(alert: Alert): Promise<boolean> {
    if (!this.isActive) return false;

    try {
      const message = this.formatAlertMessage(alert);
      const success = await this.sendMessage(message);
      
      if (success) {
        const config = await storage.getTelegramConfig();
        if (config) {
          await storage.updateTelegramConfig({
            ...config,
            messagesSent: (config.messagesSent || 0) + 1,
          });
        }
      }

      return success;
    } catch (error) {
      console.error('Failed to send alert to Telegram:', error);
      return false;
    }
  }

  async sendMorningSummary(): Promise<boolean> {
    if (!this.isActive) return false;

    try {
      const tokens = await storage.getTopTokensByVolume(10);
      const metrics = await storage.getLatestSystemMetrics();
      const unreadAlerts = await storage.getUnreadAlerts();

      const message = this.formatMorningSummary(tokens, metrics, unreadAlerts);
      const success = await this.sendMessage(message);

      if (success) {
        const config = await storage.getTelegramConfig();
        if (config) {
          await storage.updateTelegramConfig({
            ...config,
            messagesSent: (config.messagesSent || 0) + 1,
            lastSummary: new Date(),
          });
        }
      }

      return success;
    } catch (error) {
      console.error('Failed to send morning summary:', error);
      return false;
    }
  }

  async sendEveningSummary(): Promise<boolean> {
    if (!this.isActive) return false;

    try {
      const tokens = await storage.getTopTokensByVolume(5);
      const alerts = await storage.getRecentAlerts(10);

      const message = this.formatEveningSummary(tokens, alerts);
      const success = await this.sendMessage(message);

      if (success) {
        const config = await storage.getTelegramConfig();
        if (config) {
          await storage.updateTelegramConfig({
            ...config,
            messagesSent: (config.messagesSent || 0) + 1,
          });
        }
      }

      return success;
    } catch (error) {
      console.error('Failed to send evening summary:', error);
      return false;
    }
  }

  async sendTestMessage(): Promise<boolean> {
    if (!this.isActive) return false;

    const message = `🤖 *Eliza Crypto Assistant Test*\n\nBot is connected and working properly!\n\nTime: ${new Date().toISOString()}`;
    return await this.sendMessage(message);
  }

  private async sendMessage(text: string): Promise<boolean> {
    try {
      const response = await axios.post(`https://api.telegram.org/bot${this.botToken}/sendMessage`, {
        chat_id: this.chatId,
        text,
        parse_mode: 'Markdown',
        disable_web_page_preview: true,
      }, {
        timeout: 10000,
      });

      return response.status === 200;
    } catch (error) {
      console.error('Telegram API error:', error);
      return false;
    }
  }

  private formatAlertMessage(alert: Alert): string {
    const severityEmoji = {
      low: '🟡',
      medium: '🟠',
      high: '🔴',
      critical: '🚨',
    };

    const typeEmoji = {
      volume: '📊',
      price: '💰',
      whale: '🐋',
      trend: '📈',
    };

    return `${severityEmoji[alert.severity as keyof typeof severityEmoji] || '⚠️'} ${typeEmoji[alert.type as keyof typeof typeEmoji] || '📢'} *${alert.title}*\n\n${alert.description}\n\n_${new Date(alert.createdAt || '').toLocaleString()}_`;
  }

  private formatMorningSummary(tokens: Token[], metrics: SystemMetrics | undefined, alerts: Alert[]): string {
    let message = `🌅 *Morning Crypto Summary*\n\n`;

    if (metrics) {
      message += `📊 *Market Overview*\n`;
      message += `• Active Tokens: ${metrics.activeTokens}\n`;
      message += `• Total Volume (24h): $${this.formatNumber(Number(metrics.totalVolume24h || 0))}\n`;
      message += `• API Health: ${metrics.apiHealthScore}%\n\n`;
    }

    if (tokens.length > 0) {
      message += `🏆 *Top Performers*\n`;
      tokens.slice(0, 5).forEach((token, index) => {
        const change = Number(token.priceChange24h || 0);
        const changeEmoji = change > 0 ? '📈' : change < 0 ? '📉' : '➡️';
        message += `${index + 1}. ${token.symbol} - $${token.price} ${changeEmoji} ${change.toFixed(2)}%\n`;
      });
      message += '\n';
    }

    if (alerts.length > 0) {
      message += `🚨 *Unread Alerts: ${alerts.length}*\n`;
      alerts.slice(0, 3).forEach(alert => {
        message += `• ${alert.title}\n`;
      });
    }

    return message;
  }

  private formatEveningSummary(tokens: Token[], alerts: Alert[]): string {
    let message = `🌙 *Evening Market Wrap-up*\n\n`;

    if (tokens.length > 0) {
      message += `📊 *Top Volume Today*\n`;
      tokens.forEach((token, index) => {
        message += `${index + 1}. ${token.symbol} - Volume: $${this.formatNumber(Number(token.volume24h || 0))}\n`;
      });
      message += '\n';
    }

    if (alerts.length > 0) {
      message += `📢 *Today's Activity (${alerts.length} alerts)*\n`;
      const alertCounts = alerts.reduce((acc, alert) => {
        acc[alert.type] = (acc[alert.type] || 0) + 1;
        return acc;
      }, {} as Record<string, number>);

      Object.entries(alertCounts).forEach(([type, count]) => {
        message += `• ${type}: ${count}\n`;
      });
    }

    return message;
  }

  private formatNumber(num: number): string {
    if (num >= 1000000000) {
      return `${(num / 1000000000).toFixed(1)}B`;
    } else if (num >= 1000000) {
      return `${(num / 1000000).toFixed(1)}M`;
    } else if (num >= 1000) {
      return `${(num / 1000).toFixed(1)}K`;
    }
    return num.toFixed(2);
  }

  getStatus(): { isActive: boolean; botToken: boolean; chatId: boolean } {
    return {
      isActive: this.isActive,
      botToken: !!this.botToken,
      chatId: !!this.chatId,
    };
  }
}

export const telegramService = new TelegramService();
