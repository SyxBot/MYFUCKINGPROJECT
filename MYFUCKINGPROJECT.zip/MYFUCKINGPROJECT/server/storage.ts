import { 
  type User, 
  type InsertUser,
  type Token,
  type InsertToken,
  type Alert,
  type InsertAlert,
  type DataSource,
  type InsertDataSource,
  type SystemMetrics,
  type InsertSystemMetrics,
  type TelegramConfig,
  type InsertTelegramConfig
} from "@shared/schema";
import { randomUUID } from "crypto";

export interface IStorage {
  // User methods
  getUser(id: string): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;

  // Token methods
  getAllTokens(): Promise<Token[]>;
  getTokenByMint(mint: string): Promise<Token | undefined>;
  getTokenById(id: string): Promise<Token | undefined>;
  createToken(token: InsertToken): Promise<Token>;
  updateToken(id: string, token: Partial<InsertToken>): Promise<Token | undefined>;
  getTopTokensByVolume(limit: number): Promise<Token[]>;
  getTokensSorted(sort: string, order: string, limit: number, offset: number): Promise<Token[]>;
  deactivateToken(id: string): Promise<void>;

  // Alert methods
  getAllAlerts(): Promise<Alert[]>;
  getUnreadAlerts(): Promise<Alert[]>;
  createAlert(alert: InsertAlert): Promise<Alert>;
  markAlertAsRead(id: string): Promise<void>;
  getRecentAlerts(limit: number): Promise<Alert[]>;

  // Data source methods
  getAllDataSources(): Promise<DataSource[]>;
  getDataSourceByName(name: string): Promise<DataSource | undefined>;
  createDataSource(dataSource: InsertDataSource): Promise<DataSource>;
  updateDataSourceStatus(name: string, status: string, errorMessage?: string): Promise<void>;

  // System metrics methods
  getLatestSystemMetrics(): Promise<SystemMetrics | undefined>;
  updateSystemMetrics(metrics: InsertSystemMetrics): Promise<SystemMetrics>;

  // Telegram config methods
  getTelegramConfig(): Promise<TelegramConfig | undefined>;
  updateTelegramConfig(config: InsertTelegramConfig): Promise<TelegramConfig>;
}

export class MemStorage implements IStorage {
  private users: Map<string, User>;
  private tokens: Map<string, Token>;
  private alerts: Map<string, Alert>;
  private dataSources: Map<string, DataSource>;
  private systemMetrics: SystemMetrics | undefined;
  private telegramConfig: TelegramConfig | undefined;

  constructor() {
    this.users = new Map();
    this.tokens = new Map();
    this.alerts = new Map();
    this.dataSources = new Map();
    
    // Initialize data sources
    this.initializeDataSources();
  }

  private async initializeDataSources() {
    const sources = ['DEXScreener', 'Birdeye', 'CoinGecko', 'Jupiter'];
    for (const name of sources) {
      await this.createDataSource({ name, status: 'active' });
    }
  }

  // User methods
  async getUser(id: string): Promise<User | undefined> {
    return this.users.get(id);
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(
      (user) => user.username === username,
    );
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const id = randomUUID();
    const user: User = { ...insertUser, id };
    this.users.set(id, user);
    return user;
  }

  // Token methods
  async getAllTokens(): Promise<Token[]> {
    return Array.from(this.tokens.values()).filter(token => token.isActive);
  }

  async getTokenByMint(mint: string): Promise<Token | undefined> {
    return Array.from(this.tokens.values()).find(token => token.mint === mint);
  }

  async getTokenById(id: string): Promise<Token | undefined> {
    return this.tokens.get(id);
  }

  async createToken(token: InsertToken): Promise<Token> {
    const id = randomUUID();
    const newToken: Token = { 
      ...token, 
      id, 
      lastUpdated: new Date(),
      isActive: true,
      price: token.price || null,
      volume24h: token.volume24h || null,
      priceChange24h: token.priceChange24h || null,
      marketCap: token.marketCap || null,
      holders: token.holders || null,
      alphaScore: token.alphaScore || null,
      whaleIntentScore: token.whaleIntentScore || null
    };
    this.tokens.set(id, newToken);
    return newToken;
  }

  async updateToken(id: string, token: Partial<InsertToken>): Promise<Token | undefined> {
    const existing = this.tokens.get(id);
    if (!existing) return undefined;
    
    const updated: Token = { 
      ...existing, 
      ...token, 
      lastUpdated: new Date() 
    };
    this.tokens.set(id, updated);
    return updated;
  }

  async getTopTokensByVolume(limit: number): Promise<Token[]> {
    return Array.from(this.tokens.values())
      .filter(token => token.isActive && token.volume24h)
      .sort((a, b) => Number(b.volume24h || 0) - Number(a.volume24h || 0))
      .slice(0, limit);
  }

  async getTokensSorted(sort: string, order: string, limit: number, offset: number): Promise<Token[]> {
    const fieldMap: Record<string, keyof Token> = {
      'volume_24h_usd': 'volume24h',
      'volume_1h_usd': 'volume24h', // fallback to 24h
      'price_change_1h': 'priceChange24h', // fallback to 24h
      'price_change_24h': 'priceChange24h',
      'liquidity_usd': 'marketCap',
      'whale_intent_score': 'alphaScore',
      'holders': 'holders'
    };
    
    const dbField = fieldMap[sort] || 'volume24h';
    const isDesc = order === 'desc';
    
    return Array.from(this.tokens.values())
      .filter(token => token.isActive)
      .sort((a, b) => {
        const aVal = Number(a[dbField] || 0);
        const bVal = Number(b[dbField] || 0);
        return isDesc ? bVal - aVal : aVal - bVal;
      })
      .slice(offset, offset + limit);
  }

  async deactivateToken(id: string): Promise<void> {
    const token = this.tokens.get(id);
    if (token) {
      token.isActive = false;
      this.tokens.set(id, token);
    }
  }

  // Alert methods
  async getAllAlerts(): Promise<Alert[]> {
    return Array.from(this.alerts.values()).sort((a, b) => 
      new Date(b.createdAt || 0).getTime() - new Date(a.createdAt || 0).getTime()
    );
  }

  async getUnreadAlerts(): Promise<Alert[]> {
    return Array.from(this.alerts.values()).filter(alert => !alert.isRead);
  }

  async createAlert(alert: InsertAlert): Promise<Alert> {
    const id = randomUUID();
    const newAlert: Alert = { 
      ...alert, 
      id, 
      createdAt: new Date(),
      isRead: false,
      metadata: alert.metadata || null,
      tokenId: alert.tokenId || null
    };
    this.alerts.set(id, newAlert);
    return newAlert;
  }

  async markAlertAsRead(id: string): Promise<void> {
    const alert = this.alerts.get(id);
    if (alert) {
      alert.isRead = true;
      this.alerts.set(id, alert);
    }
  }

  async getRecentAlerts(limit: number): Promise<Alert[]> {
    return Array.from(this.alerts.values())
      .sort((a, b) => new Date(b.createdAt || 0).getTime() - new Date(a.createdAt || 0).getTime())
      .slice(0, limit);
  }

  // Data source methods
  async getAllDataSources(): Promise<DataSource[]> {
    return Array.from(this.dataSources.values());
  }

  async getDataSourceByName(name: string): Promise<DataSource | undefined> {
    return Array.from(this.dataSources.values()).find(ds => ds.name === name);
  }

  async createDataSource(dataSource: InsertDataSource): Promise<DataSource> {
    const id = randomUUID();
    const newDataSource: DataSource = { 
      ...dataSource, 
      id, 
      lastUpdate: new Date(),
      requestCount: 0,
      errorMessage: dataSource.errorMessage || null
    };
    this.dataSources.set(id, newDataSource);
    return newDataSource;
  }

  async updateDataSourceStatus(name: string, status: string, errorMessage?: string): Promise<void> {
    const dataSource = Array.from(this.dataSources.values()).find(ds => ds.name === name);
    if (dataSource) {
      dataSource.status = status;
      dataSource.lastUpdate = new Date();
      dataSource.errorMessage = errorMessage || null;
      dataSource.requestCount = (dataSource.requestCount || 0) + 1;
      this.dataSources.set(dataSource.id, dataSource);
    }
  }

  // System metrics methods
  async getLatestSystemMetrics(): Promise<SystemMetrics | undefined> {
    return this.systemMetrics;
  }

  async updateSystemMetrics(metrics: InsertSystemMetrics): Promise<SystemMetrics> {
    const id = this.systemMetrics?.id || randomUUID();
    this.systemMetrics = { 
      ...metrics, 
      id, 
      lastUpdated: new Date(),
      activeTokens: metrics.activeTokens || null,
      totalVolume24h: metrics.totalVolume24h || null,
      alertsSent: metrics.alertsSent || null,
      apiHealthScore: metrics.apiHealthScore || null
    };
    return this.systemMetrics;
  }

  // Telegram config methods
  async getTelegramConfig(): Promise<TelegramConfig | undefined> {
    return this.telegramConfig;
  }

  async updateTelegramConfig(config: InsertTelegramConfig): Promise<TelegramConfig> {
    const id = this.telegramConfig?.id || randomUUID();
    this.telegramConfig = { 
      ...config, 
      id,
      isActive: config.isActive || null,
      messagesSent: config.messagesSent || null,
      lastSummary: config.lastSummary || null
    };
    return this.telegramConfig;
  }
}

export const storage = new MemStorage();
