// Pure whale intent score computation
// Inputs: recent swap window, token metadata, wallet performance stats
// Output: 0-100 score indicating whale accumulation intent

export interface SwapWindow {
  uniqueWallets: number;
  netBuyUsd: number;
  slippageAvg: number;
}

export interface TokenMeta {
  lpUsd?: number | null;
  vol1hUsd?: number | null;
}

export interface WalletStats {
  hitRateAvg: number; // 0-1 success rate of wallets in window
}

export function computeWhaleIntentScore(
  evWindow: SwapWindow,
  tokenMeta: TokenMeta,
  walletStats: WalletStats
): number {
  const { uniqueWallets, netBuyUsd, slippageAvg } = evWindow;
  const { lpUsd = 0, vol1hUsd = 0 } = tokenMeta;
  const { hitRateAvg } = walletStats;

  // Base score from net buying pressure (0-40 points)
  const buyPressure = Math.max(0, netBuyUsd);
  const buyScore = Math.min(40, (buyPressure / 100000) * 40); // $100k = max 40pts

  // Liquidity impact score (0-25 points)
  const liqImpact = (lpUsd && lpUsd > 0) ? Math.min(25, (buyPressure / lpUsd) * 2500) : 0;

  // Wallet quality score (0-20 points) 
  const qualityScore = hitRateAvg * 20;

  // Low slippage preference (0-10 points)
  const slippageScore = Math.max(0, 10 - (slippageAvg * 100));

  // Unique wallet diversity bonus (0-5 points)
  const diversityScore = Math.min(5, uniqueWallets * 0.5);

  const totalScore = buyScore + liqImpact + qualityScore + slippageScore + diversityScore;
  
  // Clamp to 0-100 range
  return Math.max(0, Math.min(100, Math.round(totalScore)));
}