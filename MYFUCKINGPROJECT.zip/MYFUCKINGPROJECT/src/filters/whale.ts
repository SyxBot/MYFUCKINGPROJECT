// Minimal, framework-agnostic whale filter
// Pure functions; no I/O. Tune cfg constants as needed.

export type SwapEvent = {
  wallet: string;
  mint: string;
  symbol?: string;
  isBuy: boolean;        // true if base (USDC/SOL) -> token
  usd: number;           // notional in USD
  dex?: string;
  route?: string[];      // e.g., ["Jupiter","Orca"]
};

export type PoolMeta = {
  liqUsd?: number | null;     // pool liquidity in USD
  vol1hUsd?: number | null;   // 1h volume in USD
  holders?: number | null;    // approx holders count
  tokenAgeH?: number | null;  // token age in hours
};

export const cfg = {
  MIN_USD: 3000,              // absolute min whale size
  L_PCT: 0.005,               // 0.5% of pool liquidity
  V_PCT: 0.05,                // 5% of last-hour volume
  BURST_WINDOW_MS: 5 * 60 * 1000,
  BURST_MIN_USD: 5000,        // min total in window
  BURST_L_PCT: 0.01,          // 1% of LP in window
  MIN_HOLDERS: 50,
  MIN_LIQ_USD: 20000,
  MIN_TOKEN_AGE_H: 1,
  COOLDOWN_MS: 10 * 60 * 1000
};

// In-memory state (module-local). Kept tiny & cheap.
type Burst = { sumUsd: number; txs: { ms: number; usd: number }[]; startMs: number };
const bursts = new Map<string, Burst>();       // key: wallet|mint
const lastAlertAt = new Map<string, number>(); // key: wallet|mint

function key(wallet: string, mint: string) { return wallet + "|" + mint; }

function hygiene(meta: PoolMeta): boolean {
  const { holders, liqUsd, tokenAgeH } = meta;
  if (holders != null && holders < cfg.MIN_HOLDERS) return false;
  if (liqUsd != null && liqUsd < cfg.MIN_LIQ_USD) return false;
  if (tokenAgeH != null && tokenAgeH < cfg.MIN_TOKEN_AGE_H) return false;
  return true;
}

function passesPerSwap(ev: SwapEvent, meta: PoolMeta): boolean {
  const { usd, isBuy } = ev;
  const liq = meta.liqUsd ?? null;
  const v1h = meta.vol1hUsd ?? null;

  const byUsd = usd >= cfg.MIN_USD;
  const byLiq = liq != null ? usd >= liq * cfg.L_PCT : false;
  const byVol = v1h != null ? usd >= v1h * cfg.V_PCT : false;

  // Deprioritize immediate sells unless they meaningfully impact depth/volume.
  if (!isBuy && !(byLiq || byVol)) return false;
  return byUsd || byLiq || byVol;
}

function passesBurst(ev: SwapEvent, meta: PoolMeta, nowMs: number): boolean {
  const k = key(ev.wallet, ev.mint);
  let b = bursts.get(k);
  if (!b) { b = { sumUsd: 0, txs: [], startMs: nowMs }; bursts.set(k, b); }

  // Slide window
  const win = cfg.BURST_WINDOW_MS;
  b.txs = b.txs.filter(t => nowMs - t.ms <= win);
  b.sumUsd = b.txs.reduce((a, t) => a + t.usd, 0);

  // Add current
  b.txs.push({ ms: nowMs, usd: ev.usd });
  b.sumUsd += ev.usd;

  const liq = meta.liqUsd ?? 0;
  const bySum = b.sumUsd >= cfg.BURST_MIN_USD && b.txs.length >= 3;
  const byLiq = liq > 0 && b.sumUsd >= liq * cfg.BURST_L_PCT;

  if (bySum || byLiq) {
    // reset after alert
    bursts.set(k, { sumUsd: 0, txs: [], startMs: nowMs });
    return true;
  }
  return false;
}

function inCooldown(ev: SwapEvent, nowMs: number): boolean {
  const t = lastAlertAt.get(key(ev.wallet, ev.mint)) ?? 0;
  return (nowMs - t) < cfg.COOLDOWN_MS;
}

function markAlert(ev: SwapEvent, nowMs: number) {
  lastAlertAt.set(key(ev.wallet, ev.mint), nowMs);
}

export function shouldAlert(
  ev: SwapEvent,
  meta: PoolMeta,
  nowMs: number = Date.now()
): { alert: boolean; kind?: "WHALE_TRADE" | "WHALE_BURST"; context?: any } {
  // Guards
  if (!hygiene(meta)) return { alert: false };
  if (inCooldown(ev, nowMs)) return { alert: false };

  if (passesPerSwap(ev, meta)) {
    markAlert(ev, nowMs);
    return {
      alert: true,
      kind: "WHALE_TRADE",
      context: summarize(ev, meta)
    };
  }

  if (passesBurst(ev, meta, nowMs)) {
    markAlert(ev, nowMs);
    return {
      alert: true,
      kind: "WHALE_BURST",
      context: summarize(ev, meta)
    };
  }

  return { alert: false };
}

function summarize(ev: SwapEvent, meta: PoolMeta) {
  const liq = meta.liqUsd ?? 0;
  const v1h = meta.vol1hUsd ?? 0;
  const pctLiq = liq ? (ev.usd / liq) * 100 : null;
  const pctVol = v1h ? (ev.usd / v1h) * 100 : null;
  return {
    symbol: ev.symbol,
    isBuy: ev.isBuy,
    usd: Math.round(ev.usd),
    pctLiq: pctLiq != null ? Number(pctLiq.toFixed(2)) : null,
    pctVol: pctVol != null ? Number(pctVol.toFixed(2)) : null,
    dex: ev.dex,
    route: ev.route
  };
}